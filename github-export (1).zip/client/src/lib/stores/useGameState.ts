import { create } from 'zustand';
import { GamePhase, PlayerStats, Scene, Mission, Stat } from '../../types/game';
import { scenes } from '../../data/scenes';
import { characters } from '../../data/characters';
import { missions as gameMissions, findMissionById } from '../../data/missions';
import { useCharacter } from './useCharacter';

interface GameState {
  // Game state
  gamePhase: GamePhase;
  currentScene: string;
  activeScene: Scene | null;
  
  // Player stats
  playerStats: PlayerStats;
  
  // Missions
  missions: Mission[];
  currentMission: Mission | null;
  
  // UI states
  showInventory: boolean;
  showStats: boolean;
  showMission: boolean;
  
  // Actions
  initGame: () => void;
  setGamePhase: (phase: GamePhase) => void;
  changeScene: (sceneId: string, playerX?: number, playerY?: number) => void;
  setActiveScene: (scene: Scene) => void;
  setPlayerStats: (stats: PlayerStats) => void;
  modifyStat: (stat: Stat, amount: number) => void;
  startMission: (missionId: string) => void;
  completeMission: (missionId: string) => void;
  completeObjective: (missionId: string, objectiveId: string) => void;
  setShowInventory: (show: boolean) => void;
  setShowStats: (show: boolean) => void;
  setShowMission: (show: boolean) => void;
}

export const useGameState = create<GameState>((set, get) => ({
  // Initial game state
  gamePhase: 'intro',
  currentScene: 'university',
  activeScene: null,
  
  // Initial player stats
  playerStats: {
    creativity: 30,
    persuasion: 25,
    publicSpeaking: 20,
    research: 35
  },
  
  // Missions from our mission data file
  missions: gameMissions,
  currentMission: null,
  
  // UI states
  showInventory: false,
  showStats: false,
  showMission: false,
  
  // Initialize the game
  initGame: () => {
    set({ 
      gamePhase: 'playing',
      currentScene: 'university'
    });
    
    // Set up player character
    const initialScene = scenes.find(scene => scene.id === 'university');
    
    if (initialScene) {
      // Set the player character position
      const player = characters.find(char => char.id === 'player');
      if (player) {
        useCharacter.getState().setPlayer({
          ...player,
          x: 400,
          y: 300
        });
      }
      
      set({ activeScene: initialScene });
      
      // Start the intro mission
      const introMission = findMissionById('game_intro');
      if (introMission) {
        set({ currentMission: introMission, showMission: true });
      }
    }
  },
  
  // Change game phase
  setGamePhase: (phase) => set({ gamePhase: phase }),
  
  // Change the current scene
  changeScene: (sceneId, playerX, playerY) => {
    // Get the target scene
    const targetScene = scenes.find(scene => scene.id === sceneId);
    
    if (targetScene) {
      // Update player position if coordinates provided
      if (playerX !== undefined && playerY !== undefined) {
        const player = useCharacter.getState().player;
        if (player) {
          useCharacter.getState().setPlayer({
            ...player,
            x: playerX,
            y: playerY
          });
        }
      }
      
      // Update scene
      set({ 
        currentScene: sceneId,
        activeScene: targetScene
      });
    }
  },
  
  // Set the active scene
  setActiveScene: (scene) => set({ activeScene: scene }),
  
  // Set player stats
  setPlayerStats: (stats) => set({ playerStats: stats }),
  
  // Modify a specific stat
  modifyStat: (stat, amount) => {
    set(state => {
      const newStats = { ...state.playerStats };
      newStats[stat] = Math.max(0, Math.min(100, newStats[stat] + amount));
      return { playerStats: newStats };
    });
  },
  
  // Start a mission
  startMission: (missionId) => {
    const mission = get().missions.find(m => m.id === missionId);
    if (mission) {
      set({ 
        currentMission: mission,
        showMission: true
      });
    }
  },
  
  // Complete a mission
  completeMission: (missionId) => {
    set(state => {
      // Update mission completion status
      const updatedMissions = state.missions.map(mission => 
        mission.id === missionId 
          ? { ...mission, isCompleted: true } 
          : mission
      );
      
      // Apply mission rewards
      const completedMission = state.missions.find(m => m.id === missionId);
      if (completedMission && completedMission.reward) {
        // Apply stat rewards
        if (completedMission.reward.stats) {
          const newStats = { ...state.playerStats };
          Object.entries(completedMission.reward.stats).forEach(([stat, value]) => {
            newStats[stat as Stat] = Math.min(100, newStats[stat as Stat] + value);
          });
          
          // Add item rewards
          if (completedMission.reward.items) {
            completedMission.reward.items.forEach(itemId => {
              useCharacter.getState().addItemById(itemId);
            });
          }
          
          return { 
            missions: updatedMissions, 
            currentMission: null,
            playerStats: newStats,
            showMission: false
          };
        }
      }
      
      return { 
        missions: updatedMissions, 
        currentMission: null,
        showMission: false
      };
    });
  },
  
  // Complete a mission objective
  completeObjective: (missionId, objectiveId) => {
    set(state => {
      const updatedMissions = state.missions.map(mission => {
        if (mission.id === missionId) {
          const updatedObjectives = mission.objectives.map(objective => 
            objective.id === objectiveId 
              ? { ...objective, isCompleted: true } 
              : objective
          );
          return { ...mission, objectives: updatedObjectives };
        }
        return mission;
      });
      
      // Update current mission if it's the active one
      const updatedCurrentMission = state.currentMission && state.currentMission.id === missionId
        ? updatedMissions.find(m => m.id === missionId) || null
        : state.currentMission;
      
      return { 
        missions: updatedMissions,
        currentMission: updatedCurrentMission  
      };
    });
  },
  
  // UI state setters
  setShowInventory: (show) => set({ showInventory: show }),
  setShowStats: (show) => set({ showStats: show }),
  setShowMission: (show) => set({ showMission: show })
}));

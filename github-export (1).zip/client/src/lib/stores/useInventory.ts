import { create } from 'zustand';
import { Item } from '../../types/game';
import { items } from '../../data/items';

interface InventoryState {
  items: Item[];
  selectedItemId: string | null;
  
  addItem: (itemId: string) => void;
  removeItem: (itemId: string) => void;
  selectItem: (itemId: string | null) => void;
  hasItem: (itemId: string) => boolean;
}

export const useInventory = create<InventoryState>((set, get) => ({
  items: [],
  selectedItemId: null,
  
  // Add an item to inventory
  addItem: (itemId) => {
    const itemToAdd = items.find(item => item.id === itemId);
    
    if (itemToAdd) {
      set(state => ({ 
        items: [...state.items, itemToAdd] 
      }));
    }
  },
  
  // Remove an item from inventory
  removeItem: (itemId) => {
    set(state => ({
      items: state.items.filter(item => item.id !== itemId),
      // Deselect the item if it's the one being removed
      selectedItemId: state.selectedItemId === itemId ? null : state.selectedItemId
    }));
  },
  
  // Select an item
  selectItem: (itemId) => set({ selectedItemId: itemId }),
  
  // Check if an item is in inventory
  hasItem: (itemId) => {
    return get().items.some(item => item.id === itemId);
  }
}));

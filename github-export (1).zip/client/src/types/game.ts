// Game phase types
export type GamePhase = 'intro' | 'playing' | 'dialogue' | 'inventory' | 'mission' | 'ending';

// Character types
export interface Character {
  id: string;
  name: string;
  sprite: string;
  x: number;
  y: number;
  width: number;
  height: number;
  dialogues: string[];
  isNPC: boolean;
}

// Dialogue types
export interface DialogueOption {
  id: string;
  text: string;
  nextDialogue?: string;
  effect?: DialogueEffect;
  requiresStat?: { stat: Stat, value: number };
  requiresItem?: string;
}

export interface DialogueNode {
  id: string;
  character: string;
  text: string;
  options?: DialogueOption[];
  isMarcResponse?: boolean;
  image?: string;
}

export type DialogueEffect = {
  type: 'addItem' | 'removeItem' | 'modifyStat' | 'startMission' | 'completeMission' | 'completeObjective' | 'moveCharacter' | 'unlockScene';
  value: any;
}

// Item types
export interface Item {
  id: string;
  name: string;
  description: string;
  sprite: string;
  canUse: boolean;
  useWith?: string[];
  onUse?: () => void;
}

// Interactive object types
export interface InteractiveObject {
  id: string;
  name: string;
  sprite: string;
  x: number;
  y: number;
  width: number;
  height: number;
  zIndex: number;
  isObstacle: boolean;
  dialogueId?: string;
  onInteract?: (player: Character) => void;
}

// Scene types
export interface Scene {
  id: string;
  name: string;
  background: string;
  width: number;
  height: number;
  objects: InteractiveObject[];
  characters: Character[];
  exits: SceneExit[];
  isLocked: boolean;
}

export interface SceneExit {
  x: number;
  y: number;
  width: number;
  height: number;
  targetScene: string;
  targetX: number;
  targetY: number;
}

// Mission types
export interface Mission {
  id: string;
  title: string;
  description: string;
  objectives: Objective[];
  isCompleted: boolean;
  reward?: {
    stats?: { [key in Stat]?: number };
    items?: string[];
  }
}

export interface Objective {
  id: string;
  description: string;
  isCompleted: boolean;
}

// Stats
export type Stat = 'creativity' | 'persuasion' | 'publicSpeaking' | 'research';

export interface PlayerStats {
  creativity: number;
  persuasion: number;
  publicSpeaking: number;
  research: number;
}

// MARC AI Assistant types
export interface MarcResponse {
  text: string;
  isHelpful: boolean;
  isSarcastic: boolean;
}
